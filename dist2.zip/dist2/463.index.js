"use strict";
exports.id = 463;
exports.ids = [463];
exports.modules = {

/***/ 23463:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   hideBin: () => (/* reexport safe */ _build_lib_utils_process_argv_js__WEBPACK_IMPORTED_MODULE_3__.a)
/* harmony export */ });
/* unused harmony export applyExtends */
/* harmony import */ var _build_lib_utils_apply_extends_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70646);
/* harmony import */ var _build_lib_utils_process_argv_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(67030);
/* harmony import */ var yargs_parser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9544);
/* harmony import */ var _lib_platform_shims_esm_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(72095);





const applyExtends = (config, cwd, mergeExtends) => {
  return _applyExtends(config, cwd, mergeExtends, shim);
};




/***/ })

};
;